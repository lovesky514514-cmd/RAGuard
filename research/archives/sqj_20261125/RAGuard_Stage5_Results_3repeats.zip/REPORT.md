# Stage 5：幂等契约边界配对实验

8 个固定条件 × 2 策略 × 2 引擎 × 3 次重复＝96 条方法级执行。

| 契约条件 | 策略 | 引擎 | 运行 | 重复效果 | 错作用域 | 不安全确认 | 安全确认 | 未解决 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| native_inside | unaware | b5 | 3 | 0 | 0 | 0 | 3 | 0 |
| native_inside | unaware | raguard | 3 | 0 | 0 | 0 | 3 | 0 |
| native_inside | contract | b5 | 3 | 0 | 0 | 0 | 3 | 0 |
| native_inside | contract | raguard | 3 | 0 | 0 | 0 | 3 | 0 |
| native_at_expiry | unaware | b5 | 3 | 3 | 0 | 3 | 0 | 0 |
| native_at_expiry | unaware | raguard | 3 | 3 | 0 | 3 | 0 | 0 |
| native_at_expiry | contract | b5 | 3 | 0 | 0 | 0 | 0 | 3 |
| native_at_expiry | contract | raguard | 3 | 0 | 0 | 0 | 0 | 3 |
| native_outside | unaware | b5 | 3 | 3 | 0 | 3 | 0 | 0 |
| native_outside | unaware | raguard | 3 | 3 | 0 | 3 | 0 | 0 |
| native_outside | contract | b5 | 3 | 0 | 0 | 0 | 0 | 3 |
| native_outside | contract | raguard | 3 | 0 | 0 | 0 | 0 | 3 |
| native_cross_scope | unaware | b5 | 3 | 3 | 3 | 3 | 0 | 0 |
| native_cross_scope | unaware | raguard | 3 | 3 | 3 | 3 | 0 | 0 |
| native_cross_scope | contract | b5 | 3 | 0 | 0 | 0 | 0 | 3 |
| native_cross_scope | contract | raguard | 3 | 0 | 0 | 0 | 0 | 3 |
| no_dedupe | unaware | b5 | 3 | 3 | 0 | 3 | 0 | 0 |
| no_dedupe | unaware | raguard | 3 | 3 | 0 | 3 | 0 | 0 |
| no_dedupe | contract | b5 | 3 | 0 | 0 | 0 | 0 | 3 |
| no_dedupe | contract | raguard | 3 | 0 | 0 | 0 | 0 | 3 |
| unknown_guarantee | unaware | b5 | 3 | 0 | 0 | 0 | 3 | 0 |
| unknown_guarantee | unaware | raguard | 3 | 0 | 0 | 0 | 3 | 0 |
| unknown_guarantee | contract | b5 | 3 | 0 | 0 | 0 | 0 | 3 |
| unknown_guarantee | contract | raguard | 3 | 0 | 0 | 0 | 0 | 3 |
| before_commit_inside | unaware | b5 | 3 | 0 | 0 | 0 | 3 | 0 |
| before_commit_inside | unaware | raguard | 3 | 0 | 0 | 0 | 3 | 0 |
| before_commit_inside | contract | b5 | 3 | 0 | 0 | 0 | 3 | 0 |
| before_commit_inside | contract | raguard | 3 | 0 | 0 | 0 | 3 | 0 |
| before_commit_no_dedupe | unaware | b5 | 3 | 0 | 0 | 0 | 3 | 0 |
| before_commit_no_dedupe | unaware | raguard | 3 | 0 | 0 | 0 | 3 | 0 |
| before_commit_no_dedupe | contract | b5 | 3 | 0 | 0 | 0 | 0 | 3 |
| before_commit_no_dedupe | contract | raguard | 3 | 0 | 0 | 0 | 0 | 3 |

真实 HTTP 写入仅涉及本机隔离 Go 服务；默认 Go Server 去重行为不变。
禁用去重使用研究模式；契约准入在 B5 和 Gateway 上完全相同。
旧请求已结束与可信契约属于本试验前提；没有验证旧请求仍在途及不确定时钟。
固定场景重复不表示真实故障概率，也不能证明 RAGuard 独自优于 B5。
